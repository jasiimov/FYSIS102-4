/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package barchart_awt;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;

/**
 *
 * @author marco
 */
public class BarChart_AWT extends ApplicationFrame {

    public BarChart_AWT(String applicationTitle, String chartTitle) {
        super(applicationTitle);
        JFreeChart barChart = ChartFactory.createBarChart(
                chartTitle,
                "Maanden",
                "Aantal Koffers",
                createDataset(),
                PlotOrientation.VERTICAL,
                true, true, false
        );
        ChartPanel chartPanel = new ChartPanel(barChart);
        chartPanel.setPreferredSize(new java.awt.Dimension(560, 367));
        setContentPane(chartPanel);
    }

    private CategoryDataset createDataset() {
        final String GEVONDEN_KOFFERS = "Gevonden Koffers";
        final String VERLOREN_KOFFERS = "Verloren Koffers";
        final String januari = "januari";
        final String februari = "februari";
        final String maart = "User Rating";
        final String april = "safety";
        final String mei = "mei";
        final String juni = "juni";
        final String juli = "juli";
        final String augustus = "augustus";
        final String september = "september";
        final String oktober = "oktober";
        final String november = "november";
        final String december = "december";
        final DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        //Gevonden koffers
        dataset.addValue(1.0, GEVONDEN_KOFFERS, januari);
        dataset.addValue(3.0, GEVONDEN_KOFFERS, februari);
        dataset.addValue(5.0, GEVONDEN_KOFFERS, maart);
        dataset.addValue(6.0, GEVONDEN_KOFFERS, april);
        dataset.addValue(7.0, GEVONDEN_KOFFERS, mei);
        dataset.addValue(8.0, GEVONDEN_KOFFERS, juni);
        dataset.addValue(9.0, GEVONDEN_KOFFERS, juli);
        dataset.addValue(10.0, GEVONDEN_KOFFERS, augustus);
        dataset.addValue(11.0, GEVONDEN_KOFFERS, september);
        dataset.addValue(12.0, GEVONDEN_KOFFERS, oktober);
        dataset.addValue(13.0, GEVONDEN_KOFFERS, november);
        dataset.addValue(14.0, GEVONDEN_KOFFERS, december);
        //Verloren koffers
        dataset.addValue(5.0, VERLOREN_KOFFERS, januari);
        dataset.addValue(6.0, VERLOREN_KOFFERS, februari);
        dataset.addValue(10.0, VERLOREN_KOFFERS, maart);
        dataset.addValue(20.0, VERLOREN_KOFFERS, april);
        dataset.addValue(20.0, VERLOREN_KOFFERS, mei);
        dataset.addValue(20.0, VERLOREN_KOFFERS, juni);
        dataset.addValue(20.0, VERLOREN_KOFFERS, juli);
        dataset.addValue(20.0, VERLOREN_KOFFERS, augustus);
        dataset.addValue(20.0, VERLOREN_KOFFERS, september);
        dataset.addValue(19.0, VERLOREN_KOFFERS, oktober);
        dataset.addValue(20.0, VERLOREN_KOFFERS, november);
        dataset.addValue(15.0, VERLOREN_KOFFERS, december);

        return dataset;
    }

    public static void main(String[] args) {
        BarChart_AWT chart = new BarChart_AWT(
                "Koffers",
                "Verloren/Gevonden koffers"
        );
        chart.pack();
        RefineryUtilities.centerFrameOnScreen(chart);
        chart.setVisible(true);
    }
}
