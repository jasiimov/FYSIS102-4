/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linechart_awt;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

/**
 *
 * @author marco
 */
public class LineChart_AWT extends ApplicationFrame {

    public LineChart_AWT(String applicationTitle, String chartTitle) {
        super(applicationTitle);
        JFreeChart lineChart = ChartFactory.createLineChart(
                chartTitle,
                "Maanden", "Aantal koffers",
                createDataset(),
                PlotOrientation.VERTICAL,
                true, true, false
        );
        ChartPanel chartPanel = new ChartPanel(lineChart);
        chartPanel.setPreferredSize(new java.awt.Dimension(560, 367));
        setContentPane(chartPanel);
    }

    private DefaultCategoryDataset createDataset() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(30, "Gevonden koffers", "januari");
        dataset.addValue(20, "Gevonden koffers", "februari");
        dataset.addValue(30, "Gevonden koffers", "maart");
        dataset.addValue(40, "Gevonden koffers", "april");
        dataset.addValue(100, "Gevonden koffers", "mei");
        dataset.addValue(10, "Gevonden koffers", "juni");
        dataset.addValue(20, "Gevonden koffers", "juli");
        dataset.addValue(30, "Gevonden koffers", "augustus");
        dataset.addValue(40, "Gevonden koffers", "september");
        dataset.addValue(50, "Gevonden koffers", "oktober");
        dataset.addValue(60, "Gevonden koffers", "november");
        dataset.addValue(20, "Gevonden koffers", "december");
        dataset.addValue(40, "Verloren koffers", "januari");
        dataset.addValue(30, "Verloren koffers", "februari");
        dataset.addValue(50, "Verloren koffers", "maart");
        dataset.addValue(60, "Verloren koffers", "april");
        dataset.addValue(200, "Verloren koffers", "mei");
        dataset.addValue(23, "Verloren koffers", "juni");
        dataset.addValue(33, "Verloren koffers", "juli");
        dataset.addValue(43, "Verloren koffers", "augustus");
        dataset.addValue(53, "Verloren koffers", "september");
        dataset.addValue(63, "Verloren koffers", "oktober");
        dataset.addValue(66, "Verloren koffers", "november");
        dataset.addValue(20, "Verloren koffers", "december");
        return dataset;
    }

    public static void main(String[] args) {
        LineChart_AWT chart = new LineChart_AWT(
                "Koffers",
                "Verloren/Gevonden koffers"
        );
        chart.pack();
        RefineryUtilities.centerFrameOnScreen(chart);
        chart.setVisible(true);
    }
}
